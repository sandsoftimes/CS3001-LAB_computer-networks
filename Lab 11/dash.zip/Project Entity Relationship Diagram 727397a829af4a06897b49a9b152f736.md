# Project Entity Relationship Diagram

# ***786***

# Project Title:

***************************************************************************Library Management System***************************************************************************

# Members:

Muhammad Sherjeel Akhtar (20p_0101)
Mahad Ashraf  (20p_0563)

# Software Used:

Visual Paradiagram

# Description:

We are creating a project on Library Management System, for this purpose we’ve prepared an ERD Diagram.
The ERD will consist of following Entities.

- Admin
- Book
- Setting
- Category
- Author
- Issue_Book
- Location_Rack
- User

There will **8** tables that are going to be made in our project.
The tables will have relations with each other in the way of how they interact.
In our ERD, we’ve a total of 6 relationships between ********Entities.********

# Visual Demonstration:

Here i’m going to present different components of our ERD that we’ve made.
The software we’ve used for this purpose is **Visual Paradiagram.** 

## Admin:

![Untitled](Project%20Entity%20Relationship%20Diagram%20727397a829af4a06897b49a9b152f736/Untitled.png)

## Book:

![Untitled](Project%20Entity%20Relationship%20Diagram%20727397a829af4a06897b49a9b152f736/Untitled%201.png)

## Setting:

![Untitled](Project%20Entity%20Relationship%20Diagram%20727397a829af4a06897b49a9b152f736/Untitled%202.png)

## Author:

![Untitled](Project%20Entity%20Relationship%20Diagram%20727397a829af4a06897b49a9b152f736/Untitled%203.png)

## Category:

![Untitled](Project%20Entity%20Relationship%20Diagram%20727397a829af4a06897b49a9b152f736/Untitled%204.png)

## Issue Book:

![Untitled](Project%20Entity%20Relationship%20Diagram%20727397a829af4a06897b49a9b152f736/Untitled%205.png)

## Location_Rack:

![Untitled](Project%20Entity%20Relationship%20Diagram%20727397a829af4a06897b49a9b152f736/Untitled%206.png)

## User:

![Untitled](Project%20Entity%20Relationship%20Diagram%20727397a829af4a06897b49a9b152f736/Untitled%207.png)

## ERD Complete Demonstration:

![Untitled](Project%20Entity%20Relationship%20Diagram%20727397a829af4a06897b49a9b152f736/Untitled%208.png)

*********************************************************************In case of having difficulties in differentiating different entities, i’m attaching the PNG of the ERD also. So by zooming in, everything will be clean and clear. 
This was the Entity Relationship Diagram of our Library Management System.*********************************************************************

---

---

---

---